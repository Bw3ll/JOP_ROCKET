//cl vulnCracker_challenge.cpp /GS- /link /DYNAMICBASE:no /BASE:0x11220000
//https://stackoverflow.com/questions/13256446/compute-md5-hash-value-by-c-winapi MD5.h provided by Sanya Tayal


#include "md5.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>



int compute(char ent1,int i1,int j1,int k1,int l1, int cond, char chess[2][8][8]);
void printing(char chp [2][8][8]);

int compute(char ent1,int i1,int j1,int k1,int l1, int cond, char chess[2][8][8])
/*cond means condition for stopping printf statements
 *when cond ==1 do not print  */
{     


     int q=0;
     switch(ent1)
      {
       case '1':/************************************* RULES FOR PAWN************************************************/ 
             switch(chess[0][i1][j1])
             { 
            case'1': /*CHECKS WHETHER PAWN IS AVAILABLE OR NOT*/
                {
                  if (chess[1][i1][j1]=='1')/*FOR UPPER PLAYER*/
                  {
                       if( (chess[1][k1][l1]== '1' && l1==j1) || (i1 == 1 && chess[1][2][j1] == '1' && j1==l1 ) ) 
                        {
                         q=1;
                         if(cond == 0)  
                           printf("PLAYER 1 YOU CAN NOT OVERRUN YOUR ARMY\n");/************ERROR ERROR***************/
                        }

                       else if (chess[1][2][j1] == '2')
                        {
                          __asm{ 
                            POP ESI;
    XOR ECX,ECX;
    POP EBX;
    ADD ESP,0x10;
    JMP EDX;

    SUB EDX,0x1003B324;
    POP EAX;
    JMP ESI;

    ADD EBP,0x5F;
    XCHG ECX,EDX;
    SUB ESI,0x27;
    POP EDX;
    JMP EBX;

    ADD EDX,DWORD PTR [EAX];
    MOV EAX,ESI;
    POP ESI;
    JMP ECX;

    ADD BL,0xF;
    OR EDX,0x59000000;
    POP ECX; 
    POP ESI;
    JMP EDX;

    ADD BL,0xF;
    OR EDX,0x59000000;
    POP ECX; 
    POP ESI;
    JMP EAX;

    INC EAX;
    ADD AL,0x50;
    JMP EAX;

    DEC EDI;
    DEC ESI;
    DEC EBP;
    JMP EAX;

    DEC EDI;
    DEC ESI;
    DEC EBP;
    JMP EBX;
  }
                         q=1;
                         if(cond == 0)
                           printf("PLAYER 1 PAWN CAN'T JUMP OVER THE ENEMY\n");/************ERROR ERROR***************/
                        }

                    


                       else
                       { 
                            DWORD dummy; //just to get vp pointer in code for gadgets

                            LPVOID addy = (LPVOID)0x436000; 
                             VirtualProtect(addy, 4000, 0x04,&dummy);
                           if ( i1==1 && (k1==i1+1 || k1==i1+2) && l1==j1 )/*WHEN THE PAWN IS AT ITS INITIAL POSITION*/
                           {                                               
                                if(chess[1][k1][l1] == ' ')
                                   {
                                   chess[0][k1][l1]=chess[0][i1][j1];
                                   chess[1][k1][l1]=chess[1][i1][j1];
                                   chess[0][i1][j1]=chess[1][i1][j1]=' ';
                                   }

                                 else
                                   {
                                     q=1;
                                     if(cond == 0)
                                       printf("ILLEGAL MOVE\n");/************ERROR ERROR***************/

                                   }

                           }
               
                       
                   else if (k1==i1+1 && l1==j1)/*WHEN PAWN IS ANYWHERE ELSE*/
               {
                                if(chess[1][k1][l1] == ' ')
                                   {
                                   chess[0][k1][l1]=chess[0][i1][j1];
                                   chess[1][k1][l1]=chess[1][i1][j1];
                                   chess[0][i1][j1]=chess[1][i1][j1]=' ';
                                   }
 
                                 else
                                   {
                                    q=1;
                                    if(cond == 0)
                                      printf("ILLEGAL MOVE\n");/************ERROR ERROR***************/
                                   }

                           }

                           else if (k1 == i1+1 && ( l1==j1-1 || l1==j1+1))/*WHEN PAWN IS ANYWHERE ELSE*/
                           { 
                                if(chess[1][k1][l1] == '2')
                                   {
                                    __asm{
                                     POP ECX;
    PUSH 0x0F0;
    JMP ESI;

    ADD EBX,DWORD PTR [EAX];
    POP ECX;
    JMP ESI;

    PUSH EAX;
    PUSH EDX;
    POP EDI;
    POP ESI;
    ADD EDI,EAX;
    JMP ECX;

    INC ECX;
    ADD BL,BL;
    STC;
    AAA;
    INC EAX;
    JMP ESI;

    ADD EBX,EDX;
    PUSH EBX;
    JMP ECX;

    ADC EDI,0x0C7;
    ADD ESI,0x0041C924;
    JMP EBX;

    XOR EBX,EAX;
    INC ECX;
    PUSH EBX;
    JMP EDX;

    SUB EDX, EBX;
    XOR EAX, EAX;
    MOV DWORD PTR [EBX], EDX;
    JMP EBX;
  }
                                   chess[0][k1][l1]=chess[0][i1][j1];
                                   chess[1][k1][l1]=chess[1][i1][j1];   
                                   chess[0][i1][j1]=chess[1][i1][j1]=' ';
                                   }
               
                                else
                                   {
                                     q=1;
                                     if(cond == 0)
                                       printf("ILLEGAL MOVE\n");/************ERROR ERROR***************/

                                   }
                           }


                            else
                            {    q=1;
                                 if(cond == 0)
                                   printf("PLAYER 1 ILLEGAL MOVE\n");/************ERROR ERROR***************/

                            }

                   }

                  }

__asm{

xor edx, edi
pop edi
jmp edx

pop eax
pop ebx
ret

add ebx, 0xc
mov edi, edi
jmp dword ptr [ebx] 


push ebp
mov eax, 20
add esp, 0x10
jmp eax
}
          else if (chess[1][i1][j1]=='2')/*FOR LOWER PLAYER*/
                  {
                        if( (chess[1][k1][l1]== '2' && l1 == j1) || (i1==6 && chess[1][5][j1] == '2' && j1==l1 ) )
                        {
                         q=1;
                         if(cond == 0)  
                           printf("PLAYER 2 YOU CAN NOT OVERRUN YOUR ARMY\n");/************ERROR ERROR***************/
                        }
 
                        else if (chess[1][5][j1] == '1')
                        {
                         q=1;
                         if(cond == 0)
                           printf("PLAYER 2 PAWN CAN'T JUMP OVER THE ENEMY\n");/************ERROR ERROR***************/
                        }


                       else
                       {
                           if ( i1==6 && (k1==i1-1 || k1==i1-2) && l1==j1 )/*WHEN THE PAWN IS AT ITS INITIAL POSITION*/
                           {
                                if(chess[1][k1][l1] == ' ')
                                   {
                                   chess[0][k1][l1]=chess[0][i1][j1];
                                   chess[1][k1][l1]=chess[1][i1][j1];
                                   chess[0][i1][j1]=chess[1][i1][j1]=' ';
                                   }

                                 else
                                   {
                                    q=1;
                                    if(cond == 0)
                                      printf("ILLEGAL MOVE\n");/************ERROR ERROR***************/

                                   }

                           }

__asm{
add esp, 0x180
jmp edx 

pop edi
sub ch, ah
jmp ebx



dec eax
pop ebx
jmp ebx

}
                           else if (k1==i1-1 && l1==j1)/*WHEN PAWN IS ANYWHERE ELSE*/
                           {
                                if(chess[1][k1][l1] == ' ')
                                   {
                                   chess[0][k1][l1]=chess[0][i1][j1];
                                   chess[1][k1][l1]=chess[1][i1][j1];
                                   chess[0][i1][j1]=chess[1][i1][j1]=' ';
                                   }

                                 else
                                   {
                                    q=1;
                                    if(cond == 0)
                                      printf("ILLEGAL MOVE\n");/************ERROR ERROR***************/
                                   }

                           }

                           else if (k1 == i1-1 && ( l1==j1-1 || l1==j1+1))/*WHEN PAWN IS ANYWHERE ELSE*/
                           {
                                if(chess[1][k1][l1] == '1')
                                   {
                                   chess[0][k1][l1]=chess[0][i1][j1];
                                   chess[1][k1][l1]=chess[1][i1][j1];
                                   chess[0][i1][j1]=chess[1][i1][j1]=' ';
                                   }

                                else
                                   {
                                    q=1;
                                    if(cond == 0)
                                      printf("ILLEGAL MOVE\n");/************ERROR ERROR***************/
                                   }
                           }
    
                  
                   else
                           {        q=1;   
                                    if(cond == 0)
                                      printf("YOUR MOVE IS ILLEGAL\n");/************ERROR ERROR***************/
                           }
    
                }
                  }

                break;}/*BREAK OF CASE 1*/  

     
__asm{
pop edi
jmp ebx


xor edx, ebp
push ebp
pop ebp
jmp ebx

}

                default:
                       {  q=1;
                          if(cond == 0)
                            printf("PAWN IS NOT AT THE SPECIFIED POSITION\n");/************ERROR ERROR***************/
                       }

             }break;/**********************************************END OF PAWN***********************************/
 

__asm{
mov word ptr [eax], bx
pop edi
call edi

xor ebx, ebx
pop edi
call esi

push eax
pop edi
jmp ebx


}

       case '2' : /******************************************RULES FOR KNIGHT*********************************/
             switch(chess[0][i1][j1])    
             { case '2':/***CHECKS WHETHER KNIGHT IS THERE OR NOT******/
                       {     
                             if( (k1 == i1+2 || k1 == i1-2) && (k1>=0 && k1<=7) && (l1 == j1+1 || l1 == j1-1) && (l1>=0 && l1<=7) )
                             {/*******FOR VERTICAL MOVEMENT*************/
                                        if(chess[1][i1][j1] == chess[1][k1][l1] )
                                        {
                                            q =1;
                                            if(cond == 0)
                                              printf("YOU CANNOT OVERRUN YOUR ARMY\n"); /************ERROR ERROR***************/
                                        }
                                    

                                        else
                                        {
                                          __asm{
    XOR EBX, EDI;
    MOV EAX, DWORD PTR [EAX];
    NEG ESI;
    JMP ECX;

    ADC BL,AL;
    MOV EAX,0x1001DB30;
    JMP EDI;

    LES ESP,FWORD PTR [EAX];
    MOV EAX,1;
    JMP EDX;

    POP EBP; 
    POP EBX;
    ADD ESP,8;
    JMP EAX;

    MOV ESI,0x0E9000008;
    JMP EDI;

    MOV ESI,0x0E9000008;
    JMP ECX;

    ADD ESP,0x0C;
    XOR EAX,EAX;
    POP ESI;
    POP EBX;
    JMP ECX;

    MOV EAX,0x12C;
    JMP EDI;

    PUSH EAX;
    POP EDI;
    POP ESI;
    MOV EAX,EBX 
    JMP ECX;

    PUSH ECX;
    POP ESI;
    POP EAX;
    MOV EBX,EAX 
    JMP EDI;
  }
                                             chess[0][k1][l1]=chess[0][i1][j1];
                                             chess[1][k1][l1]=chess[1][i1][j1];
                                             chess[0][i1][j1]=chess[1][i1][j1]=' ';

                                        }
                                 
                             }
                          
 
__asm{
dec ebp
mov edi, eax
pop edi
jmp ebx


 push edi
 push ebp
 call esi



add esp, 0x200
jmp eax

 
 mov al, 0x0f
 mov cx, edx
 xor di, di
jmp edx
}                      
                            else if( (k1 == i1+1 || k1 == i1-1) && (k1>=0 && k1<=7) && (l1 == j1+2 || l1== j1-2) && (l1>=0 && l1<=7) )
                             {/*********FOR HORIZONTAL MOVEMENT***********/
                                        if(chess[1][i1][j1] == chess[1][k1][l1] )
                                        {
                                            q =1;
                                            if(cond == 0)
                                              printf("YOU CANNOT OVERRUN YOUR ARMY\n");/************ERROR ERROR***************/
                                        }


                                        else
                                        {
                                             chess[0][k1][l1]=chess[0][i1][j1];
                                             chess[1][k1][l1]=chess[1][i1][j1];
                                             chess[0][i1][j1]=chess[1][i1][j1]=' ';

                                        }

                             }

                             else
                             {
                                        q =1;
                                        if(cond == 0)
                                          printf("YOUR KNIGHT MOVE IS ILLEGAL\n");/************ERROR ERROR***************/
                             }
                             
               break;}/*BREAK OF CASE 2*/

__asm{
xchg eax, ebp
dec ebx 
push ebx
call esi

pop ebp
pop eax
pop edi
jmp ebx


pop ebp
mov edi, 3
call ebx  
}

               default:
                      {
                        q =1;
                        if(cond == 0)
                          printf("KNIGHT IS NOT AT THE SPECIFIED POSITION\n");/************ERROR ERROR***************/
                      }               

             }break;/***********************************END OF KNIGHT********************************************/
        

 
       case'3':/***************************************RULE OF NO-ENTITY 3 ****************************************/
             {
                   q =1;
                   if(cond == 0)
                     printf("THERE IS NO ENTITY 3\n");/************ERROR ERROR***************/

             }break;/***********************************END OF NO-ENTITY 3 ****************************************/



__asm{

inc eax 
dec edi 
call ebx

add esi, 4
add ebx, 4
jmp dword ptr [esi + 0x10]  

mov esi, ebp
ret

mov edi, edi
ret
pop ebp
pop esi
ret
}
       case'4':/****************************************RULES OF BISHOP****************************************/
              switch(chess[0][i1][j1])
                     { case '4': /***CHECKS WHETHER BISHOP IS THERE OR NOT******/
                              {    int bis;
                                   bis = k1 - i1;                                     
                                /*   printf("%d\n",bis);*/

                                   if(l1 == bis + j1 || l1 == (-1)*bis + j1)
                                   {      int var = bis - 1;
                                           

                                          if(bis < 0){
                                               var = (-1)*bis -1;
                                           }
                                     
                                          for(var; var >0; var--)
                                          {    
                                               if(bis > 0 && l1 > j1)
                                               { 
                                                   if(chess[1][i1+var][j1+var] == ' ')
                                                   continue;     

                                                   else
                                                   {
                                                       q =1;
                                                       if(cond == 0)
                                                         printf("BISHOP CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                       break;
                                                   }
                                               }

                                               else if(bis > 0 && l1 < j1)
                                               {
                                                   if(chess[1][i1+var][j1-var] == ' ')
                                                   continue;

                                                   else
                                                   {
                                                       q =1;
                                                       if(cond == 0)
                                                         printf("BISHOP CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                       break;
                                                   }
                                               }

                                               else if(bis < 0 && l1 > j1)
                                               {
                                                   if(chess[1][i1-var][j1+var] == ' ')
                                                   continue;

                                                   else
                                                   {
                                                       q =1;
                                                       if(cond == 0)
                                                         printf("BISHOP CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                       break;

                                                   }
                                               }

                                               if(bis < 0 && l1 < j1)
                                               {
                                                   if(chess[1][i1-var][j1-var] == ' ')
                                                   continue;

                                                   else
                                                   {
                                                       q =1;
                                                       if(cond == 0)
                                                         printf("BISHOP CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                       break;

                                                   }
                                               }

                                          }


                                          if(chess[1][i1][j1] == chess[1][k1][l1])
                                          {
                                              q =1;
                                              var = 1;
                                              if(cond == 0)
                                                printf("YOU CANNOT OVERRUN YOUR ARMY\n"); /************ERROR ERROR***************/
                                          }


                                          if(var == 0)
                                          {
                                              chess[0][k1][l1]=chess[0][i1][j1];
                                              chess[1][k1][l1]=chess[1][i1][j1];
                                              chess[0][i1][j1]=chess[1][i1][j1]=' ';

                                          }

                                   }

                                   else
                                   {
                                         q =1;
                                         if(cond == 0)
                                           printf("INVALID MOVE OF BISHOP\n"); /************ERROR ERROR***************/
                                   }
                              




                 break;}/***END OF CASE 4 ***********/

__asm{

add esp, 0x59
jmp ebx


sub esi, 0x6
jmp dword ptr [esi] 




pop esi
xor ebx, edi
jmp eax
}


                 default:
                        {   q =1;
                            if(cond == 0)
                              printf("BISHOP IS NOT AT THE SPECIFIED POSITION\n"); /************ERROR ERROR***************/
                        }


              }break; /*********************************END OF BISHOP**************************************/



       case '5' : /******************************************RULES FOR ROOK*********************************/
             switch(chess[0][i1][j1])
             { case '5':/***CHECKS WHETHER ROOK IS THERE OR NOT******/
                       {
                             if(l1==j1)
                             {/*******FOR VERTICAL MOVEMENT*************/
                                        int rip;
                                        rip = k1 - i1;
                                        int vap = rip-1;           

                                        if(rip <0)
                                        {
                                           vap = (-1)*rip-1;
                                        }

                                        for(vap; vap>0; vap--)
                                        { 
                                             if(rip>0)
                                             {   
                                                  if(chess[1][i1 + vap][j1] == ' ')
                                                  continue;

                                                  else
                                                  {  
                                                      q =1; 
                                                      if(cond == 0)
                                                        printf("ROOK CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                      break;
                                                  }
                                             }

                                             else if(rip<0)
                                             {
                                                  if(chess[1][i1 - vap][j1] == ' ')
                                                  continue;
                        
                                                  else
                                                  {
                                                      q =1;
                                                      if(cond == 0)
                                                        printf("ROOK CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                      break;
                                                  }
                                             }

                                        }

                                        if(chess[1][i1][j1] == chess[1][k1][l1] )
                                        {
                                            q =1;
                                            vap = 1;
                                            if(cond == 0)
                                              printf("YOU CANNOT OVERRUN YOUR ARMY\n");/************ERROR ERROR***************/
                                        }


                                        if(vap ==0)
                                        {
                                             chess[0][k1][l1]=chess[0][i1][j1];
                                             chess[1][k1][l1]=chess[1][i1][j1];
                                             chess[0][i1][j1]=chess[1][i1][j1]=' ';
                                             __asm{ 
                                              ADD ECX, EBX;
                                              MOV DWORD PTR [ECX + 8], ESI;
                                              NEG ESI;
                                              JMP ECX;

                                              MOV EBX, DWORD PTR [EBX];
                                              ADD ESP, EAX;
                                              JMP EDX;

                                              MOV DWORD PTR [EAX],ESI;
                                              POP ESI;
                                              POP EBP;
                                              JMP EAX; 

                                              MOV DWORD PTR [EAX],ESI;
                                              POP ESI;
                                              POP EBP;
                                              JMP EBX; 

                                              INC EAX;
                                              JMP ESI;
                                            }

                                        }

                             }

                             else if(k1==i1)
                             {/******FOR HORIZONTAL MOVEMENT*************/
                                        int rhip;
                                        rhip = l1 - j1;
                                        int vhap = rhip -1 ;

                                        if(rhip <0)
                                        {  
                                           vhap = (-1)*rhip-1;
                                        }

                                        for(vhap; vhap>0; vhap--)
                                        {
                                             if(rhip>0)
                                             {
                                                  if(chess[1][i1][j1 + vhap] == ' ')
                                                  continue;

                                                  else
                                                  {   
                                                      q =1;
                                                      if(cond == 0)
                                                        printf("ROOK CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                      break;
                                                  }
                                             }

                                             else if(rhip<0)
                                             {
                                                  if(chess[1][i1][j1 - vhap] == ' ')
                                                  continue;

                                                  else
                                                  {
                                                      q =1;
                                                      if(cond == 0)
                                                        printf("ROOK CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                      break;
                                                  }
                                             }


                                        }

                                        if(chess[1][i1][j1] == chess[1][k1][l1] )
                                        {   
                                            q =1;
                                            vhap = 1;
                                            if(cond == 0)
                                              printf("YOU CANNOT OVERRUN YOUR ARMY\n"); /************ERROR ERROR***************/
                                        }


                                        if(vhap ==0)
                                        {
                                             chess[0][k1][l1]=chess[0][i1][j1];
                                             chess[1][k1][l1]=chess[1][i1][j1];
                                             __asm{
                                              INC ESI;
    
    ADD ESP,0x2188;
    POPAD;
    MOV EAX,ECX;
    JMP EDX;

    ADD BH,0xB;
    ADC ESI,0x1003B28C;
    JMP ECX;

    CLD;
    NOP;
    ADC ECX,EDX;
    JMP EAX;

    ADD EBX,ESI;
    JMP DWORD PTR[EBX];

    POP EBX;
    ADD ESP,0x11;
    JMP EDI;

    AND ECX,2;
    DEC ECX;
    MOV EAX,ECX;
    JMP EDX;

    ADD ESP,0x14;
    XOR EAX,EAX;
    POP EDI;
    POP ESI;
    JMP EBX;

    POP EDI;
    POP ESI;
    JMP DWORD PTR [ESI];

    INC EAX;
    ADD AL,0x50;
    JMP EBX;

    INC EDX;
    ADD BL,0x99;
    JMP EBX;

    DEC EDI;
    SUB ESI,0x88;
    INC EBX;
    CLD;
    JMP ECX;
  }
                                             chess[0][i1][j1]=chess[1][i1][j1]=' ';

                                        }

                              }
                        
                           else
                              {
                                 q =1;
                                 if(cond == 0)
                                   printf("INVALID MOVE FOR ROOK\n"); /*******ERROR ERROR*********/
                               
                              }


                   break;}/***END OF CASE 5 ***********/


               default:
                      { 
                        q =1;
                        if(cond == 0)
                          printf("ROOK IS NOT AT THE SPECIFIED POSITION\n");/***********ERROR ERROR**************/
                      }

              }break; /*******************************END OF ROOK**************************************/




       case'6':/***************************************RULE OF NO-ENTITY 6 ****************************************/
             {
                   q =1;
                   if(cond == 0)
                     printf("THERE IS NO ENTITY 6\n");/************ERROR ERROR***************/
__asm{ 
  DEC ESP;
    AND AL,0x24;
    POP EDI;
    POP ESI;
    MOV EAX,1;
    POP EBX;
    JMP EDX;

    ADD BH,AL
    INC ECX;
    PUSH 0x1E0;
    JMP EDX;

    ADD BYTE PTR [EAX],AL;
    ADD CL,CL;
    JMP EDI;

    XCHG EAX,EDX;
    XCHG EDX,EDI;
    ADD EAX,EDI;
    JMP ECX;

    PUSH EBX;
    XOR EBX,EBX;
    INC EDX;
    PUSH EDX;
    JMP ESI;

    INC ESI;
    INC ECX;
    DEC EDI;
    POP ECX;
    JMP EDX;

    ADC EDX, ECX;
    JMP EAX;

    MOV EBX,0;
    MOV EAX,EBX;
    JMP ECX;

    POP ECX;
    XOR ECX,EAX;
    JMP EAX;
  }
             }break;/***********************************END OF NO-ENTITY 6 ****************************************/





       case'7':/***************************************RULE OF QUEEN ****************************************/
             switch(chess[0][i1][j1])/***CHECKS WHETHER QUEEN IS THERE OR NOT******/
                 { case'7':
                           {
                         
                            if(l1==j1)
                             {/*******FOR VERTICAL MOVEMENT*************/
                                        int rip;
                                        rip = k1 - i1;
                                        int vap = rip-1;

                                        if(rip <0)
                                        {  
                                           vap = (-1)*rip-1;
                                        }

                                        for(vap; vap>0; vap--)
                                        {
                                             if(rip>0)
                                             {
                                                  if(chess[1][i1 + vap][j1] == ' ')
                                                  continue;

                                                  else
                                                  {   
                                                      q =1;
                                                      if(cond == 0)
                                                        printf("QUEEN CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                      break;
                                                  }
                                             }

                                             else if(rip<0)
                                             {
                                                  if(chess[1][i1 - vap][j1] == ' ')
                                                  continue;

                                                  else
                                                  {
                                                    __asm{
                                                     DEC ESI;
                                                      NEG EDI;
                                                      JMP EDX;

                                                      ADD EAX, 0x12;
                                                      XOR EDX, EDX;
                                                      JMP DWORD PTR [EAX];

                                                      XCHG EAX, EDX;
                                                      POP EDX;
                                                      POP ECX;
                                                      POP EBX;
                                                      JMP ECX;

                                                      SUB AL, CL;
                                                      IMUL EBX;
                                                      JMP ECX;

                                                      SUB EDX, 0x8182a;
                                                      XOR EAX, EAX;
                                                      MOV DWORD PTR [ECX], EDX;
                                                      JMP ESI;

                                                      SUB EDX, 0x8182a;
                                                      XOR EAX, EAX;
                                                      MOV DWORD PTR [ECX], EDX;
                                                      JMP ECX;

                                                      MOV EBX, EDI;
                                                      ADD EAX, 0x121123;
                                                      JMP ECX;
                                                    }
                                                      q =1;
                                                      if(cond == 0)
                                                        printf("QUEEN CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                      break;
                                                  }
                                             }

                                        }

                                        if(chess[1][i1][j1] == chess[1][k1][l1] )
                                        {
                                            q =1;
                                            vap = 1;
                                            if(cond == 0)
                                              printf("YOU CANNOT OVERRUN YOUR ARMY\n");/************ERROR ERROR***************/
                                        }


                                        if(vap ==0)
                                        {
                                             chess[0][k1][l1]=chess[0][i1][j1];
                                             chess[1][k1][l1]=chess[1][i1][j1];
                                             chess[0][i1][j1]=chess[1][i1][j1]=' ';

                                        }


                                        __asm{
                                          ADD ESP, 0x200C;
                                          RET;
                                        }
                             }

                             else if(k1==i1)
                             {/******FOR HORIZONTAL MOVEMENT*************/
                                        int rhip;
                                        rhip = l1 - j1;
                                        int vhap = rhip -1 ;

                                        if(rhip <0)
                                        {
                                           vhap = (-1)*rhip-1;
                                        }

                                        for(vhap; vhap>0; vhap--)
                                        {
                                             if(rhip>0)
                                             {
                                                  if(chess[1][i1][j1 + vhap] == ' ')
                                                  continue;

                                                  else
                                                  {
                                                      q =1;
                                                      if(cond == 0)
                                                        printf("QUEEN CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                      break;
                                                  }
                                             }

                                             else if(rhip<0)
                                             {
                                                  if(chess[1][i1][j1 - vhap] == ' ')
                                                  continue;

                                                  else
                                                  {
                                                      q =1;
                                                      if(cond == 0)
                                                        printf("QUEEN CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                      break;
                                                  }
                                             }


                                        }

                                        if(chess[1][i1][j1] == chess[1][k1][l1] )
                                        {
                                            q =1;
                                            vhap = 1;
                                            if(cond == 0)
                                              printf("YOU CANNOT OVERRUN YOUR ARMY\n"); /************ERROR ERROR***************/
                                        }


                                        if(vhap ==0)
                                        {
                                             chess[0][k1][l1]=chess[0][i1][j1];
                                             chess[1][k1][l1]=chess[1][i1][j1];
                                             __asm{
    ADD ESI,4;
    JMP DWORD PTR [ESI+EAX];

    INC ESI;
    ADD AL,0x0C6;
    INC EBP;
    CLD;
    JMP ECX;

    ADC EAX,0x1003B3DC;
    MOV EAX,EDI;
    JMP ESI;

    AND AL,0x0C;
    MOV DWORD PTR [ECX+0CH],EAX;
    JMP ESI;

    AAS;
    POP ESI;
    ADD BYTE PTR [EAX],AL;
    POP ECX;
    JMP EBX;

    INC EAX;
    PUSH EAX;
    JMP ESI;

    POP ECX;
    PUSH 1;
    POP EAX;
    JMP EDX;

    OR EDI, ESI;
    ADD AL,0xC;
    PUSH ESP;
    JMP ESI;

    DEC ECX;
    ADD DL,BYTE PTR [EAX];
    JMP EBX;
}
                                             chess[0][i1][j1]=chess[1][i1][j1]=' ';

                                        }

                              }
                         
 
                              else
                              {    int bis;
                                   bis = k1 - i1;
                                   /*printf("%d\n",bis);*/

                                   if(l1 == bis + j1 || l1 == (-1)*bis + j1)
                                   {      int var = bis - 1;


                                          if(bis < 0){
                                               var = (-1)*bis -1;
                                           }

                                          for(var; var >0; var--)
                                          {
                                               if(bis > 0 && l1 > j1)
                                               {
                                                   if(chess[1][i1+var][j1+var] == ' ')
                                                   continue;

                                                   else
                                                   {
                                                       q =1;
                                                       if(cond == 0)
                                                         printf("QUEEN CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                       break;
                                                   }
                                               }

                                               else if(bis > 0 && l1 < j1)
                                               {
                                                   if(chess[1][i1+var][j1-var] == ' ')
                                                   continue;

                                                   else
                                                   {
                               q =1;
                                                       if(cond == 0)
                                                         printf("QUEEN CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                       break;
                                                   }
                                               }

                                               else if(bis < 0 && l1 > j1)
                                               {   
                                                   if(chess[1][i1-var][j1+var] == ' ')
                                                   continue;

                                                   else
                                                   {   
                                                       q =1;
                                                       if(cond == 0)
                                                         printf("QUEEN CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                       break;

                                                   }
                                               }

                                               if(bis < 0 && l1 < j1)
                                               {   
                                                   if(chess[1][i1-var][j1-var] == ' ')
                                                   continue;

                                                   else
                                                   {   
                                                       q =1;
                                                       if(cond == 0)
                                                         printf("QUEEN CAN'T JUMP\n");/*******ERROR ERROR*********/
                                                       break;

                                                   }
                                               }

                                          }

__asm{

sub edi, 0x4
jmp dword ptr [edi] 


add esp, 0x40
add ebx, 1
jmp eax
}
                                          if(chess[1][i1][j1] == chess[1][k1][l1])
                                          {
                                              q =1;
                                              var = 1;
                                              if(cond == 0)
                                                printf("YOU CANNOT OVERRUN YOUR ARMY\n"); /************ERROR ERROR***************/
                                          }


                                          if(var == 0)
                                          {
                                              chess[0][k1][l1]=chess[0][i1][j1];
                                              chess[1][k1][l1]=chess[1][i1][j1];
                                              chess[0][i1][j1]=chess[1][i1][j1]=' ';

                                          }

                                   }

                                   else
                                   {
                                            q =1;
                                            if(cond == 0)
                                              printf("INVALID MOVE FOR QUEEN\n");/*******ERROR ERROR*********/
                                   }

                              }


                  break;}/********END OF CASE 7 ************/


__asm{


mov ptr dword [eax], ebp
pop edi
jmp edx


pop eax
pop ebx
jmp edx


pop edi
jmp edx


  }

                default:
                      {
                        q =1;
                        if(cond == 0)
                          printf("QUEEN IS NOT AT THE SPECIFIED POSITION\n");/***********ERROR ERROR**************/
                      }
                 
              }break;/***********************************END OF QUEEN ****************************************/




       case'9':/***************************************RULE OF KING ****************************************/
             switch(chess[0][i1][j1])/***CHECKS WHETHER QUEEN IS THERE OR NOT******/
             {case'9':
                     {
                       
                        if( (k1 == i1 + 1 || k1 == i1-1) && (l1 == j1 || l1==j1-1 || l1 == j1+1) )
                        {

                              if(chess[1][i1][j1] == chess[1][k1][l1])
                              {  
                                  q =1; 
                                  if(cond == 0)
                                    printf("YOU CANNOT OVERRUN YOUR ARMY\n"); /************ERROR ERROR***************/
                              }


                              else
                              {
                                  chess[0][k1][l1]=chess[0][i1][j1];
                                  chess[1][k1][l1]=chess[1][i1][j1];
                                  chess[0][i1][j1]=chess[1][i1][j1]=' ';

                               }


                        }  

                        else if( (k1 == i1) && (l1==j1-1 || l1 == j1+1) )
                        {

                              if(chess[1][i1][j1] == chess[1][k1][l1])
                              {
                                  q =1;
                                  if(cond == 0)
                                    printf("YOU CANNOT OVERRUN YOUR ARMY\n"); /************ERROR ERROR***************/
                              }


                              else                                  
                              {
                                  chess[0][k1][l1]=chess[0][i1][j1];
                                  chess[1][k1][l1]=chess[1][i1][j1];
                                  chess[0][i1][j1]=chess[1][i1][j1]=' ';

                               }


                        }

                   
                        else
                        {
                               q =1;
                               if(cond == 0)
                                 printf("ILLEGAL MOVE FOR KING\n"); /************ERROR ERROR***************/
                        }
                    


               break;}/********END OF CASE 9 ************/



__asm{


mov ptr dword [eax], ebp
pop edi
jmp edx


pop eax
pop ebx
jmp edx


pop edi
jmp edx

}

                default:
                      { 
                        q =1;
                        if(cond == 0)
                          printf("KING IS NOT AT THE SPECIFIED POSITION\n");/***********ERROR ERROR**************/
                      }


             }break;/***********************************END OF KING **************************************/


       default:{ 
                if(cond == 0)
                  printf("OTHER THAN THE ALLOWED NUMBERS , CHARACTERS NOT ALLOWED AS ENTITY\nLOOK INTO HELP\n");/************ERROR ERROR***************/
               }

     }/*****************END OF SWITCH(ENTITY)************************/
   
    return q;    

}/*END OF COMPUTE*/

__asm{

pop edi
pop ebp
jmp edx

push edi
 push ebp
add esp, 0x20
jmp ebx


push ebp
pop edi
jmp edx
}



void printing(char chp [2][8][8])
{     
     int a,b;
     a =b =0;
     int  len, brd, buffer;   /*len = length & brd = breadth*/
     brd = len = 8;
     printf("\n\n\n\n\n");

     printf("                             \x1b[31m PLAYER \x1b[0m                            \n");
     printf("           1      2      3      4      5      6      7      8    \n");
     buffer = len;
     printf("       --");

      for(len; len>0; len--){
       printf("-------");
      }

      printf("\n");
      len = buffer;

      int i;
      char alpha = 'A';
      int vert = 0;
      for(brd; brd>0; brd--)
      {
          a = 8 - brd;
          i = 3;
          if(i==3)
          {
              len = buffer;
              int hor =0;

              printf("       |");
              for(len; len>0; len--)
              {
                  if( (hor+vert)%2 == 0 )
                  {
                    printf("       ");
                  }

                  else if( (hor+vert)%2 != 0 )
                  {
                    break;
                    //printf("\u2588\u2588\u2588\u2588\u2588\u2588\u2588");     /* the characters inside the print statement*/
                  }                                                           /* are unicodes used for printing the chess grid*/
                  hor++;
                  __asm{
                    ADD ESP,0x14;
    OR EAX,0x0FFFFFFFF;
    POP EDI;
    JMP ESI;

    ADD ESP,0x24;
    XOR EAX,EAX;
    POP EDI;
    JMP ESI;

    ADD ESP,0x10;
    MOV EAX,0x10024C38;
    JMP ECX;

    ADD BH,0xB;
    ADC EAX,0x1003B388;
    JMP DWORD PTR [EAX];

    ADD BH,0xB;
    ADC EAX,0x1003B388;
    JMP ECX;

    ADD ESP,0x3C;
    JMP ESI;

    POP ECX;
    MOV EAX,ESI;
    POP ESI;
    JMP EDX;

    PUSH EBX;
    JMP EDI;

    PUSH ESI;
    JMP ECX;

    ADD AL,0x27;
    NOP;
    NOP;
    NOP;
    MOV CL,AL;
    NOP;
    MOV EAX,0x00416888;
    JMP DWORD PTR [ECX];

    SUB ESI,6;
    XOR EAX,EAX;
    JMP DWORD PTR [ESI]

    ADD EBX,5;
    XOR EAX,EBX;
    JMP DWORD PTR [EBX];
}
              }

              printf("|");
              printf("\n");
              i--;
         }

         if(i==2)
         {
              len = buffer;
              int hor =0;
              printf("     %c |",alpha);

              for(len; len>0; len--)
              {
                  b = 8 - len;
                  if( (hor+vert)%2 == 0 )
                  {
                      if(chp[1][a][b] == '1')
                      {
                       printf("   \x1b[31m%c\x1b[0m   ", chp[0][a][b]);                   /*unicode*/
                      }

                      if(chp[1][a][b] == ' ')
                      {
                       printf("       ");
                      }

                      if(chp[1][a][b] == '2')
                      {
                       printf("   \x1b[32m%c\x1b[0m   ", chp[0][a][b]);                   /*unicode*/
                      }
                  }

                  else if( (hor+vert)%2 != 0 )
                  {
                      if(chp[1][a][b] =='1')
                      {
                        break;
                       //printf("\u2588\u2588\u258C\x1b[31m%c\x1b[0m\u2590\u2588\u2588", chp[0][a][b]);
                      }

                      if(chp[1][a][b] =='2')
                      {
                        break;
                      // printf("\u2588\u2588\u258C\x1b[32m%c\x1b[0m\u2590\u2588\u2588", chp[0][a][b]);
                      }

                      if(chp[1][a][b] ==' ')
                      {
                        break;
                      // printf("\u2588\u2588\u2588\u2588\u2588\u2588\u2588", chp[0][a][b]);
                      }

                  }
                  hor++;

             }

              printf("| %c", alpha);
              printf("\n");
              i--;
         }

         if(i==1)
         {
              len = buffer;
              printf("       |");
              int hor =0;

               for(len; len>0; len--)
               {
                  if( (hor+vert)%2 == 0 )
                  {
                    printf("       ");
                  }

                  else if( (hor+vert)%2 != 0 )
                  {
                    break;
                    //printf("\u2588\u2588\u2588\u2588\u2588\u2588\u2588");
                  }
                  hor++;

               }

             printf("|");
             printf("\n");
             i--;
         }

          alpha++;
          vert++;
     }


     len = buffer;
     printf("       --");

      for(len; len>0; len--){
       printf("-------");
      }
             printf("\n");

     printf("           1      2      3      4      5      6      7      8    \n");
     printf("                             \x1b[32mCOMPUTER\x1b[0m                            \n\n");
     printf("       '1'=>PAWN        '2'=>KNIGHT          '4'=>BISHOP\n       '5'=>ROOK        '7'=>QUEEN           '9'=>KING");
     printf("\n\n");
     __asm{
    POP EBX;
    XOR EAX, EAX;
    XOR EDX, EDX;
    JMP EBX;

    SUB ECX, 0x10;
    JMP DWORD PTR [EDX];

    POP EDI;
    AND EDI, EAX;
    POP EAX;
    JMP EBX;

    SUB EBX, 0x4;
    INC EAX;
    JMP DWORD PTR [EBX];

    ADD ECX, 0x12;
    OR CL, AL;
    JMP DWORD PTR [ECX];

    MOV ESI, EDI;
    ADD ESI, 0x121;
    JMP ESI;

    MOV DWORD PTR [EDX + 0x8], EAX;
    JMP EBX;
  }


}





























































//-------------------------------------------- END FILLER ----------------------------------------------------------------------------------------

void jopfunc()
{
 


    __asm
    {
        ADD EDI, 0x4;
        JMP EDI;
    }

    
    __asm 
    {   
        ADD EDI, 0x0000000c;
        JMP DWORD PTR [EDI];
    }

     __asm
    {   
        ADD EDI, 8;
        JMP DWORD PTR [EDI];
    }

    __asm
    {
        ADD EBX, 0x20;
        ADD ECX, EBX;
        CALL EBX;
    }
    
    __asm 
    {   
        ADD EAX, EDX;
        POP EAX;
        JMP EDX;
    }

    
    __asm 
    {
        MOV ESI, EDI;
        SUB EBX, EAX;
        INC EBX;
        JMP EDX;
    }

    __asm 
    {
        INC EBP;
        ADD CX,BX;
        CLD;
        SUB ESP, 0x22d
    }

    __asm 
    {
        MOV EAX, DWORD PTR [EBP+0x6];
        XOR EBX, EDX;
        RET;
    }

    
    __asm 
    {
        MOV ECX, 0x0552a200;
        MOV EBP, 0x40204040;
        JMP EDX;
    }

    __asm 
    {
        ADD EBX, 0x00000022;
        CALL EBX;
    }

    
    __asm 
    {
        INC ESI;
        XOR ECX, EAX;
        MOV EBP, ECX;
        JMP EDX;
    }

    __asm
    {
        ADD EBX, EBX;
        XOR EBX, DWORD PTR [EAX];
        CLD;
        JMP EAX;
    }

    
    __asm 
    {
        ADD EAX, 0x00000004;
        JMP EDX;
    }

    
    __asm 
    {
        MOV EAX, ESP;
        JMP EDX;
    }

    __asm 
    {
        XOR EAX, EAX;
        XOR ECX, ECX;
        PUSHAD;
        POP ECX;
        JMP DWORD PTR [ECX];
    }

    
    __asm
    {
        PUSH EAX;
        PUSH ECX;
        XOR EAX, EAX;
        JMP EDX;
    }

    __asm
    {
        ADD EAX, EAX;
        INC EAX;
        XOR EAX, DWORD PTR [EBX];
        CALL DWORD PTR [EDI];
    }


    
    __asm 
    {
        MOV ESI, 0x10102222;
        PUSH EBX;
        JMP EAX;
    }

    __asm
    {
        SUB ESP,DWORD PTR [EBP]
        CLD;
        JMP EDI;
    }

    __asm 
    {
        ADD EBX, ECX;
        ADD EAX, EBX;
        XOR EAX, ECX;
        JMP DWORD PTR [EDX]
    }

    
    __asm 
    {
        JMP DWORD PTR [ESP];
    }

    
    __asm 
    {
        XOR EBP, 0x710c3411;
        MOV ESP, EBP;
        JMP EDX;
    }

    
    __asm
    {
        MOV ESP,EBP;
        JMP EDX;
    }

    __asm 
    {
        XOR EAX, EAX;
        PUSHAD;
        SUB EDX,0x2921dd
        JMP ECX;
    }
    
    __asm 
    {
        ADD ESP,0x4;
        JMP EDX;
    }

    
    __asm 
    {
        SUB ESP,0x8;
        JMP EDX;
    }

    __asm
    {
        MOV EAX, DWORD PTR [ESI+0x20];
        CALL DWORD PTR [EAX];
    }

    
    __asm 
    {
        INC EAX;
        ADD EBX, ECX;
        MOV ECX, DWORD PTR [ECX];
        JMP EDX;
    }

    __asm 
    {
        ADD ESP, 0x894;
        MOV EBP,ESP;
        JMP EDX;
    }

    
    __asm 
    {
        POP EDX;
        POP EBP;
        NOP;
        SUB EBX, EAX;
        INC EDX;
        INC EDX;
        INC EDX;
        INC EDX;
        RET;

    }


    __asm 
    {
        CLD;
        ADD EAX, DWORD PTR [EDI];
        JMP EBX;
    }

    __asm 
    {
        MOV EDX, ESP;
        RET 0xC;
    }

    
    __asm 
    {
        MOV EBX, EAX;
        ADD EBX, ECX;
        JMP EDX;
    }

    __asm
    {
        IMUL EDI;
        JMP EDX;
    }

    __asm 
    {
        MOV EDX, ESP;
        RET 0xC;
        NOP;
        JMP EDX;
    }
    
    __asm 
    {
        ADD ESP,0x4f;
        POP EAX;
        POP EDX;
        POP EDI;
        XOR EDX,EAX;
        XOR EDI,EAX;
        CALL EDX;
    }

    __asm
    {
        ADD ESP,0xc;
        INC EAX;
        JMP EDX;
    }

    __asm 
    {
        PUSH ECX;
        PUSH EAX;
        XOR EAX, ECX;
        CALL EDX;
    }

    __asm 
    {
        MOV ECX, 0xFFFFAE12;
        MOV EBX, 0x20400000;
        JMP EDX;
    }

    __asm
    {
        MOV EAX,0x000011FA;
        XCHG EAX,ESI;
        CALL EDX;
    }

    __asm 
    {
        SUB ESP,0x4f
        POP EAX;
        POP EDX;
        POP EDI;
        XOR EDX,EAX;
        XOR EDI,EAX;
        CALL EDX;
    }

    __asm 
    {
        SUB ESP,0x6f;
        MOV EAX,4;
        POPAD;
        XCHG EDI, EBX;
        XOR EDI, EBX
        SUB EDX, ESI;
        XOR EDI, ECX;
        JMP EDX;
    }

    __asm 
    {
        XOR EBP, 0x55128F3E;
        ADD EBP, 0x7FED;
        MOV ESP, EBP;
        CALL ECX;
    }

    __asm 
    {
        IMUL ECX;
        XCHG EBP, ESP;
        JMP EBX;
    }

    __asm 
    {
        ADD EBX, 0x10;
        JMP DWORD PTR [EBX];
    }

    __asm 
    {
        SUB ESI, 0x6;
        JMP DWORD PTR [ESI];
    }

    __asm 
    {
        PUSH EAX;
        PUSH ECX;
        XOR EAX, EAX;
        JMP ESI;
    }

    __asm
    {
        ADC EAX,0x0027b068;
        POP EBP;
        RET;
    }

    __asm
    {
        OR EAX,0x0fff12aa;
        POP EBP;
        RET;
    }

    __asm
    {   
        MOV EAX,EDX;
        CLD;
        JMP EDX;
    }

    __asm
    {   
        ADD EAX, EDX;
        POP EAX;
        JMP DWORD PTR [EDX];
    }

    __asm
    {
        MOV ESP,EBP;
        JMP ECX;
    }

    __asm
    {
        DEC EDI;
        DEC ESI;
        ADD ESI,EDI;
        MOV EAX,EBX;
        PUSHAD;
        JMP EAX;
    }

    __asm 
    {
        XCHG EAX,ESP;
        SUB EAX,0xc;
        MOV ESP,EAX;
        JMP EDX;
    }

    __asm
    {
        ADD EBX, 0x283e;
        ADD ESP,0x10;
        JMP EDX;
    }

    __asm
    {
        ADD ESI,EDI;
        JMP DWORD PTR [ESI];
    }

    __asm 
    {
        SUB ESP,0x8;
        CALL EDX;
    }

    __asm 
    {
        MOV EAX, 0x10102222;
        PUSH EBX;
        MOV ECX,EDX;
        CALL ECX;
    }

    __asm 
    {
        MOV ESI,EDI;
        ADD EAX,0x73;
        XOR ECX,EAX;
        MOV EBX,ECX;
        JMP EDX;
    }

    __asm 
    {
        ADD ESP,0x18;
        JMP EDX;
    }

    __asm 
    {
        POP EDX;
        POP EAX;
        PUSH EDX;
        ADD ECX,0x20007;
        JMP EBX;
    }

    __asm 
    {
        MOV ESP, 0x00435500;
        JMP EDX; 
    }

    __asm 
    {
        ADD ESP,0x8;
        JMP EDX;
    }

    __asm
    {
        ADD ESP,0x10;
        JMP EDX;
    }

    __asm
    {
        ADD ESP,0x18;
        JMP EDX;
    }

    __asm
    {
        POP EAX;
        POP EBX;
        XOR EBX, EAX;
        RET;
    }

    __asm
    {
        ADD EAX, 0x4;
        MOV EAX, DWORD PTR [EAX];
        RET;
    }

    __asm
    {
        PUSHAD;
        RET;
    }

    __asm 
    {
        MOV ECX, DWORD PTR [EBX];
        RET;
    }

    __asm 
    {
        XOR ESP, EDI;
        ADD EDI, 0x802;
        RET;
    }

    __asm 
    {
        ADD ECX,EAX;
        INC EBX;
        DEC EDX;
        RET;
    }

    __asm 
    {
        SUB ESP,0x6f;
        MOV EAX,4;
        POPAD;
        XCHG EDI, EBX;
        XOR EDI, EBX
        SUB EDX, ESI;
        XOR EDI, ECX;
        RET;
    }

    __asm 
    {
        ADD EAX, EDX;
        POP EAX;
        CALL EDX;
    }

    __asm
    {
        SUB EBX, 0x6f;
        MOV DWORD PTR [EBX], ECX;
        JMP EDX;
    }

    __asm
    {
        PUSH EBX;
        CALL EDX;
    }
}

bool checkMatch(char line[], char userHash[]){
	MD5 md5;
	char trimLine[50];
	strtok(line, "\n");
	bool result = (strcmp(md5.digestString(line), userHash) == 0);
    if(strlen(line) > 50)
        memcpy((void *)trimLine, (const void *)line, 1000);
	//strcpy(trimLine, line);
	return result;
}

int main(int argc, char* argv[]){

	char out[50];
	if(argc < 2)
	{
		puts("Usage: vulnCracker.cpp <passwordDictionary.txt>");
		return 0;
	}

	MD5 md5;
    int hashType;
    char junk;
    char passwordHash[70];
	printf("Enter hash to crack: ");
	scanf("%s", passwordHash);

	FILE* file = fopen(argv[1], "r");
	char line[1000];
	while(fgets(line, 1000, file)){
		if(feof(file)){
			fclose(file);
			printf("Password not found.\n");
			return 0;
		}
		else{
			//printf("%s\n", line);
			//printf("Line md5: %s | userHash: %s\n", md5.digestString(strtok(line, "\n")), userHash);
			if(checkMatch(line, passwordHash))
			{
				printf("Password: %s\n", line);
				fclose(file);
				return 0;
			}
				
		}
	}
    printf("Password not found.\n");
    return 0;
}

    void stuff(){
         DWORD dummy;
    //rwx mem for memcpy later
    LPVOID addy = (LPVOID)0x436000; 
    VirtualProtect(addy, 4000, 0x04,&dummy);
    }

